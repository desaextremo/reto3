package com.atenea.reto3.controller;

import com.atenea.reto3.entity.Reservation;
import com.atenea.reto3.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/Reservation/")
@CrossOrigin(origins = "*")
public class ReservationController {
    @Autowired
    private ReservationService businness;

    //Listar mensajes
    @GetMapping("/all")
    public List<Reservation> getReservations(){
        return businness.getReservations();
    }

    //agregar mensaje
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public void addReservation(@RequestBody Reservation reservation){
        businness.addReservation(reservation);
    }
}
