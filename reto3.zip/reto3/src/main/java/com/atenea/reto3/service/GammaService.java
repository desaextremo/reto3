package com.atenea.reto3.service;


import com.atenea.reto3.entity.Gama;
import com.atenea.reto3.repository.GammaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GammaService {
    //atributo de relacion
    @Autowired
    private GammaRepository repository;

    //Lista las gamas
    public List<Gama> getGamas(){
        return repository.findAll();
    }

    //Ingresa una gama
    public void addGamma(Gama gama){
        repository.save(gama);
    }
}
