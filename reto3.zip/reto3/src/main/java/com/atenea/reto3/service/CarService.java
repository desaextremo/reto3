package com.atenea.reto3.service;

import com.atenea.reto3.entity.Car;
import com.atenea.reto3.repository.CarRepository;
import com.atenea.reto3.repository.GammaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarService {
    @Autowired
    private CarRepository repository;

    //listar carros
    public List<Car> getCars(){
        return repository.findAll();
    }

    //agregar carro
    public void addCar(Car car){
        repository.save(car);
    }
}
