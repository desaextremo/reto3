package com.atenea.reto3.entity;

public class Admin {
}
