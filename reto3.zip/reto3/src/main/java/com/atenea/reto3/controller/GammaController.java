package com.atenea.reto3.controller;

import com.atenea.reto3.entity.Gama;
import com.atenea.reto3.service.GammaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/Gama/")
@CrossOrigin(origins = "*")
public class GammaController {
    //atributo de relacion
    @Autowired
    private GammaService businnes;

    //Lista las gamas
    @GetMapping("/all")
    public List<Gama> getGamas(){
        return businnes.getGamas();
    }

    //Ingresa una gama
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    private void addGamma(@RequestBody Gama gama){
        businnes.addGamma(gama);
    }
}
