package com.atenea.reto3.service;

import com.atenea.reto3.entity.Message;
import com.atenea.reto3.repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageService {
    @Autowired
    private MessageRepository repository;

    //Listar mensajes
    public List<Message> getMessages(){
        return repository.findAll();
    }

    //agregar mensaje
    public void addMessage(Message message){
        repository.save(message);
    }
}
