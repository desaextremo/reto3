package com.atenea.reto3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.atenea.reto3.entity.Car;

public interface CarRepository extends JpaRepository<Car,Long> {
}
