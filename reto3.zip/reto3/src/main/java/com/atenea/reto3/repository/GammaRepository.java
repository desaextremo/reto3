package com.atenea.reto3.repository;

import com.atenea.reto3.entity.Gama;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GammaRepository extends JpaRepository <Gama, Long> {
}
