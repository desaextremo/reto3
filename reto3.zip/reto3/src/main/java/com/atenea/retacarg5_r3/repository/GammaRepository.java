package com.atenea.retacarg5_r3.repository;

import com.atenea.retacarg5_r3.entity.Gama;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GammaRepository extends JpaRepository <Gama, Long> {
}
