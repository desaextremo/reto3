package com.atenea.retacarg5_r3.repository;

import com.atenea.retacarg5_r3.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservationRepository extends JpaRepository<Reservation,Long> {
}
