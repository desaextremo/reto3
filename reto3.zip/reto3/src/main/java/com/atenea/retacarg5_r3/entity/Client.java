package com.atenea.retacarg5_r3.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name="clients")
@Data
public class Client {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idClient;
    @Column(nullable = false,length = 45 )
    private String email;
    @Column(nullable = false,length = 45 )
    private String password;
    @Column(nullable = false,length = 250 )
    private String name;
    @Column(nullable = false )
    private Integer age;
}
