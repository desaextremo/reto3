package com.atenea.retacarg5_r3.entity;

public class Score {
}
