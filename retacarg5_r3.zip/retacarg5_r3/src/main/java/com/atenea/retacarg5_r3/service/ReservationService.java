package com.atenea.retacarg5_r3.service;

import com.atenea.retacarg5_r3.entity.Message;
import com.atenea.retacarg5_r3.entity.Reservation;
import com.atenea.retacarg5_r3.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReservationService {
    @Autowired
    private ReservationRepository repository;

    //Listar mensajes
    public List<Reservation> getReservations(){
        return repository.findAll();
    }

    //agregar mensaje
    public void addReservation(Reservation reservation){
        repository.save(reservation);
    }
}
