package com.atenea.retacarg5_r3.controller;

import com.atenea.retacarg5_r3.entity.Gama;
import com.atenea.retacarg5_r3.repository.GamaRepository;
import com.atenea.retacarg5_r3.service.GamaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/Gama")
@CrossOrigin(origins = "*")
public class GamaController {
    @Autowired
    private GamaService business;

    //Listar gamas
    @GetMapping("/all")
    public List<Gama> getGamas(){
        return business.getGamas();
    }

    //insertar Gamas
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public void addGama(@RequestBody Gama gama){
        business.addGama(gama);
    }
}
