package com.atenea.retacarg5_r3.controller;

import com.atenea.retacarg5_r3.entity.Client;
import com.atenea.retacarg5_r3.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;

import java.util.List;

@RestController
@RequestMapping("/api/Client/")
@CrossOrigin(origins = "*")
public class ClientController {
    @Autowired
    private ClientService businnes;

    //listar clientes
    @GetMapping("/all")
    public List<Client> getCLients(){
        return businnes.getCLients();
    }

    //agregar clientes
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public void addClient(@RequestBody Client client){
        businnes.addClient(client);
    }
}
