package com.atenea.retacarg5_r3.controller;

import com.atenea.retacarg5_r3.entity.Car;
import com.atenea.retacarg5_r3.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Car/")
public class CarController {
    @Autowired
    private CarService businnes;

    //listar carros
    @GetMapping("/all")
    public List<Car> getCars(){
        return businnes.getCars();
    }

    //agregar carro
    @PostMapping("/save")
    public void addCar(@RequestBody Car car){
        businnes.addCar(car);
    }

}
