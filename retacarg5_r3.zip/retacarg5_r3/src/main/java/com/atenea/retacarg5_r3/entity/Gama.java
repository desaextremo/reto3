package com.atenea.retacarg5_r3.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
@Table(name="gamas")
public class Gama {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idGama;
    @Column(nullable = false,length = 45)
    private String name;
    @Column(nullable = false,length = 250)
    private String description;
    
    //Relacion con Carro
    @OneToMany(cascade = CascadeType.PERSIST,mappedBy = "gama")
    @JsonIgnoreProperties("gama")
    private List<Car> cars;
}
