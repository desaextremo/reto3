package com.atenea.retacarg5_r3.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.util.List;
import lombok.Data;
@Entity
@Table(name="clients")
@Data
public class Client {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idClient;
    @Column(nullable = false,length = 45 )
    private String email;
    @Column(nullable = false,length = 45 )
    private String password;
    @Column(nullable = false,length = 250 )
    private String name;
    @Column(nullable = false )
    private Integer age;
    
    //relacion con mensaje
    @OneToMany(cascade = CascadeType.PERSIST,mappedBy = "client")
    @JsonIgnoreProperties("client")
    private List<Message> messages;
    
    //relacion con mensaje
    @OneToMany(cascade = CascadeType.PERSIST,mappedBy = "client")
    @JsonIgnoreProperties("client")
    private List<Reservation> reservations;
}
