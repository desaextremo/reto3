package com.atenea.rentacarg3_r3.repository;

import com.atenea.rentacarg3_r3.entity.Car;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarRepository extends JpaRepository<Car,Integer> {
}
