package com.atenea.rentacarg3_r3.entity;

import jakarta.persistence.*;
import lombok.Data;
import com.atenea.rentacarg3_r3.entity.Gama;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@Entity
@Data
@Table(name="cars")
public class Car {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idCar;
    @Column(nullable = false,length = 45)
    private String name;
    @Column(nullable = false,length = 45)
    private String brand;
    @Column(nullable = false)
    private Integer year;
    @Column(nullable = false,length = 250)
    private String description;

    //atributo de relacion con gama
    @ManyToOne
    @JoinColumn(name="idGama")
    @JsonIgnoreProperties("cars")
    private Gama gama;
    
    //atributos de relacion con Mensaje
    @OneToMany(cascade=CascadeType.PERSIST,mappedBy = "car")
    @JsonIgnoreProperties({"car","client"})
    private List<Message> messages;
    
    //relacion con Reservation
    @OneToMany(cascade = CascadeType.PERSIST,mappedBy = "car")
    @JsonIgnoreProperties({"car","messages"})
    private List<Reservation> reservations;
}
