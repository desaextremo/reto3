package com.atenea.rentacarg3_r3.controller;

import com.atenea.rentacarg3_r3.entity.Car;
import com.atenea.rentacarg3_r3.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/Car")
public class CarController {
    @Autowired
    private CarService bussiness;

    //listar carros
    @GetMapping("/all")
    public List<Car> getCars(){
        return bussiness.getCars();
    }

    //registra carros
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public void addCar(@RequestBody Car car){
        bussiness.addCar(car);
    }
}
