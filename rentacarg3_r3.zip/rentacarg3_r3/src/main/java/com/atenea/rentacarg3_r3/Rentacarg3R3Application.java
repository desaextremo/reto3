package com.atenea.rentacarg3_r3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Rentacarg3R3Application {

    public static void main(String[] args) {
        SpringApplication.run(Rentacarg3R3Application.class, args);
    }

}
